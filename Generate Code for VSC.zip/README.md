
  # Generate Code for VSC

  This is a code bundle for Generate Code for VSC. The original project is available at https://www.figma.com/design/7vYnGzWsm1CJDfucldg0tS/Generate-Code-for-VSC.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  