
  # Pattern für VSC erstellen

  This is a code bundle for Pattern für VSC erstellen. The original project is available at https://www.figma.com/design/3ArlCmO3YQvKDy252BpkmJ/Pattern-f%C3%BCr-VSC-erstellen.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  